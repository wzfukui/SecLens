"""Ubuntu security notice collector plugin package."""

__all__ = [
    "collector",
]
